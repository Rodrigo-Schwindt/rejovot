<?php

namespace App\Services\Odoo;

use Illuminate\Support\Facades\Log;

/**
 * Pedidos del cliente en Odoo (sale.order).
 *
 * Se leen en vivo: un pedido cambia de estado todo el tiempo y no tiene sentido
 * espejarlo como el catálogo. Siempre acotado al partner del cliente activo,
 * para que nadie pueda ver los pedidos de otro.
 */
class OdooPedidos
{
    /** Lo confirmado, más los presupuestos que el propio cliente cargó desde la web. */
    protected const ESTADOS_VISIBLES = ['sale', 'done', 'cancel'];

    protected const CAMPOS = [
        'name',
        'date_order',
        'amount_untaxed',
        'amount_tax',
        'amount_total',
        'state',
        // Nada que facturar / por facturar / facturado.
        'invoice_status',
        'carrier_id',
        'client_order_ref',
        'order_line',
    ];

    public function __construct(protected OdooClient $odoo)
    {
    }

    /** Últimos pedidos del cliente, del más nuevo al más viejo. */
    public function delCliente(int $partnerId, int $limite = 25): array
    {
        return $this->odoo->searchRead('sale.order', $this->dominio($partnerId), self::CAMPOS, [
            'limit' => $limite,
            'order' => 'date_order desc, id desc',
        ]);
    }

    /** Un pedido por número, siempre validando que sea de ese cliente. */
    public function porNumero(int $partnerId, string $numero): ?array
    {
        $rows = $this->odoo->searchRead('sale.order', [
            ...$this->dominio($partnerId),
            ['name', '=', $numero],
        ], self::CAMPOS, ['limit' => 1]);

        return $rows[0] ?? null;
    }

    public function cuantos(int $partnerId): int
    {
        return $this->odoo->searchCount('sale.order', $this->dominio($partnerId));
    }

    /**
     * Líneas de varios pedidos en una sola llamada, agrupadas por pedido.
     *
     * @return array<int, array<int, array<string, mixed>>>
     */
    public function lineas(array $pedidos): array
    {
        $ids = [];

        foreach ($pedidos as $pedido) {
            foreach ($pedido['order_line'] ?? [] as $lineaId) {
                $ids[] = $lineaId;
            }
        }

        if (! $ids) {
            return [];
        }

        $rows = $this->odoo->read('sale.order.line', $ids, [
            'order_id',
            'product_id',
            'name',
            'product_uom_qty',
            'qty_delivered',
            'price_unit',
            'price_subtotal',
            'discount',
            'display_type',
            'is_delivery',
        ]);

        $porPedido = [];

        foreach ($rows as $row) {
            // Las secciones y notas del pedido no son productos.
            if (! empty($row['display_type'])) {
                continue;
            }

            $porPedido[$row['order_id'][0]][] = $row;
        }

        return $porPedido;
    }

    /**
     * Crea el pedido en Odoo e intenta confirmarlo. Al confirmar, Odoo revisa
     * la cuenta corriente con sus reglas de excepción:
     *  - Sin problemas: queda como «Pedido de venta» y entra en el filtro
     *    «SIN IMPRIMIR CONFIRMADA P/EMPRESA».
     *  - Deuda vencida o límite de crédito excedido: queda como «Presupuesto
     *    enviado» con la excepción a la vista, y Rejovot lo revisa a mano.
     *
     * Los precios NO se mandan: Odoo los calcula con la tarifa del cliente al
     * crear cada línea, igual que cuando cargan un pedido a mano. Lo único que
     * se manda con precio es la línea del envío, que es como la arma Odoo.
     *
     * @param  array<int, array{product_id:int, cantidad:float}>  $lineas
     * @param  array{id:int, producto_id:?int, importe:float}|null  $envio
     * @return array{id:int, name:string, estado:string, excepcion:?string}
     */
    public function crear(int $partnerId, array $lineas, ?array $envio, ?int $vendedorUid, string $observaciones = ''): array
    {
        $partner = $this->odoo->read('res.partner', [$partnerId], [
            'property_payment_term_id',
            'property_account_position_id',
            'user_id',
        ])[0] ?? [];

        $orderLines = array_map(fn (array $l) => [0, 0, [
            'product_id' => $l['product_id'],
            'product_uom_qty' => $l['cantidad'],
        ]], $lineas);

        if ($envio && $envio['producto_id']) {
            $orderLines[] = [0, 0, [
                'product_id' => $envio['producto_id'],
                'product_uom_qty' => 1,
                'price_unit' => $envio['importe'],
                'is_delivery' => true,
            ]];
        }

        $id = $this->odoo->create('sale.order', [
            'partner_id' => $partnerId,
            'company_id' => config('odoo.company_id'),
            'warehouse_id' => config('odoo.warehouse_id'),
            // Lo que en pantalla pone el onchange del cliente.
            'payment_term_id' => $partner['property_payment_term_id'][0] ?? false,
            'fiscal_position_id' => $partner['property_account_position_id'][0] ?? false,
            // La venta se le acredita al vendedor que la cargó; si no, al de la cartera.
            'user_id' => $vendedorUid ?: ($partner['user_id'][0] ?? false),
            'carrier_id' => $envio['id'] ?? false,
            'origin' => 'Web',
            'website_id' => config('odoo.website_id'),
            'order_line' => $orderLines,
        ]);

        if (trim($observaciones) !== '') {
            // Al chatter del pedido: ahí lo ve quien lo prepara.
            $this->odoo->call('sale.order', 'message_post', [[$id]], [
                'body' => 'Mensaje del cliente desde la web: ' . e(trim($observaciones)),
                'message_type' => 'comment',
            ]);
        }

        $this->confirmar($id);

        $creado = $this->odoo->read('sale.order', [$id], ['name', 'state', 'main_exception_id'])[0] ?? [];

        return [
            'id' => $id,
            'name' => $creado['name'] ?? (string) $id,
            'estado' => $creado['state'] ?? 'draft',
            'excepcion' => $creado['main_exception_id'][1] ?? null,
        ];
    }

    /**
     * Confirma el pedido. Si la cuenta corriente tiene una excepción, Odoo no lo
     * confirma (devuelve el aviso en vez de error) y se marca «Presupuesto
     * enviado», como pidió Rejovot. Si Odoo rechaza la confirmación por otro
     * motivo, el pedido igual quedó creado: se registra y se sigue, para no
     * perderle el pedido al cliente.
     */
    protected function confirmar(int $id): void
    {
        try {
            $this->odoo->call('sale.order', 'action_confirm', [[$id]]);
        } catch (OdooException $e) {
            Log::warning("Odoo no confirmó el pedido web {$id}: " . $e->getMessage());

            return;
        }

        $pedido = $this->odoo->read('sale.order', [$id], ['state', 'main_exception_id'])[0] ?? [];

        if (($pedido['state'] ?? null) === 'draft' && ! empty($pedido['main_exception_id'])) {
            $this->odoo->call('sale.order', 'action_quotation_sent', [[$id]]);
        }
    }

    protected function dominio(int $partnerId): array
    {
        return [
            ['partner_id', '=', $partnerId],
            ['company_id', '=', config('odoo.company_id')],
            '|',
            ['state', 'in', self::ESTADOS_VISIBLES],
            '&', ['state', 'in', ['draft', 'sent']], ['origin', '=', 'Web'],
        ];
    }
}
