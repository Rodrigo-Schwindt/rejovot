<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Datos institucionales del sitio: NO vienen de Odoo, se cargan desde el admin.
 */
class Contact extends Model
{
    protected $table = 'contact';

    protected $fillable = [
        'direction_adm',
        'phone_amd',
        'mail_adm',
        'mail_comprobantes',
        'mail_reclamos',
        'avisar_pedidos',
        'wssp',
        'maps_adm',
        'frame_adm',
        'facebook',
        'insta',
        'linkedin',
        'youtube',
        'icono_1',
        'icono_2',
        'icono_3',
    ];

    /**
     * Casilla que recibe los comprobantes de pago. Si no se cargó una propia,
     * van al mail de contacto general.
     */
    public static function mailComprobantes(): ?string
    {
        $contacto = static::first();

        return $contacto?->mail_comprobantes ?: $contacto?->mail_adm;
    }

    /** Casilla que recibe los reclamos. Sin una propia, van al mail de contacto. */
    /** Si se manda el mail de cada pedido (lo prende o apaga el admin en Contacto). */
    public static function avisaPedidos(): bool
    {
        return (bool) (static::first()?->avisar_pedidos ?? true);
    }

    public static function mailReclamos(): ?string
    {
        $contacto = static::first();

        return $contacto?->mail_reclamos ?: $contacto?->mail_adm;
    }

    public function infoItems()
    {
        return $this->hasMany(ContactInfoItem::class)->orderBy('sort_order')->orderBy('id');
    }
}
