<?php

use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Schedule;

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote');

// El catálogo se refresca solo: el sync es incremental por write_date
// (de la variante y de la plantilla, donde se despublica o archiva).
Schedule::command('odoo:sync-catalog')->everyThirtyMinutes()->withoutOverlapping();

// Precio, stock, activo y publicado de todo el catálogo: el precio y el stock
// cambian sin tocar la fecha de modificación, así que se releen seguido.
// Una pasada tarda alrededor de un minuto.
Schedule::command('odoo:sync-precios')->everyFiveMinutes()->withoutOverlapping();

// Ofertas: los descuentos van entre fechas, así que se revisan seguido.
Schedule::command('odoo:sync-ofertas')->hourly()->withoutOverlapping();

// Clientes y vendedores: cambian menos que el catálogo.
Schedule::command('odoo:sync-clientes')->hourly()->withoutOverlapping();

// Alternativos y accesorios: necesitan el catálogo ya sincronizado.
Schedule::command('odoo:sync-relacionados')->dailyAt('04:15')->withoutOverlapping();

// Las marcas se deducen del nombre, así que se recalculan después del sync.
Schedule::command('catalogo:marcas')->dailyAt('04:30')->withoutOverlapping();

// La lista de precios descargable se rearma cada hora con los precios del momento.
Schedule::command('precios:generar')->hourlyAt(20)->withoutOverlapping();
